########################
#Author: Colin Craig
#GIS 540 Project
#Date: 5/6/12
########################


import arcpy,sys,os,glob
from arcpy.sa import *
import cacraig_modules

Output_counter=0

if __name__ == '__main__':
    
    #Get Input Params from user, set ENV
    if arcpy.GetParameterAsText(0) == "":
        Current_Dir=sys.path[0]
        path=os.path.split(Current_Dir)[0]+"\data"
        arcpy.env.workspace=path
    else:
        arcpy.env.workspace=arcpy.GetParameterAsText(0)
        
    clip_extent=arcpy.GetParameterAsText(1)
    cell_size=arcpy.GetParameterAsText(2)
    os.chdir(arcpy.env.workspace)
    arcpy.env.overwriteOutput=1

    #Loop through each *.csv file in specified dir
    for filename in glob.glob("*.csv"):
        Output_counter=Output_counter+1
        if arcpy.GetParameterAsText(0) == "":
            Current_Dir=sys.path[0]
            path=os.path.split(Current_Dir)[0]+"\data"
            arcpy.env.workspace=path
        else:
            arcpy.env.workspace=arcpy.GetParameterAsText(0)
        arcpy.env.overwriteOutput=1
        #
        #Create a new folder for all output for each precipitation *.csv file
        output_dir=arcpy.env.workspace+"\Interpolation_Output"+str(Output_counter)
        dirs=os.listdir(arcpy.env.workspace)
        #If output folders exist, delete them and recreate them.
        for dir in dirs:
            if os.path.split(output_dir)[1] == dir:
                arcpy.AddMessage("DELETING FOLDER "+dir)
                import shutil
                shutil.rmtree(output_dir)        
        arcpy.AddMessage("Creating Folder: Interpolation_Output "+str(Output_counter))
        arcpy.CreateFolder_management(arcpy.env.workspace, "/Interpolation_Output"+str(Output_counter))
        arcpy.SetProgressor("step","Progressor",0,100,(100/3))
        #
        #Instantiate object of type Precip_Map
        Precip_Map=cacraig_modules.Precip_Map(filename,Output_counter)
        arcpy.AddMessage("Creating Shapefile "+Precip_Map.shp+" in "+output_dir)
        #
        #Generate dbf,and shp file from input *.csv
        Precip_Map.Get_Data_From_ASCII(output_dir,filename)
        arcpy.env.workspace=output_dir
        arcpy.SetProgressorPosition()
        fields = arcpy.ListFields(Precip_Map.shp)
        #
        #Search for 'Precip' field header in dbf file, if not found, skip iteration
        for field in fields:
            if(field.name.endswith("Precip")):
                Precip_Map.Z_field=field.name
        if Precip_Map.Z_field.endswith("Precip")==0:
            break
            
        arcpy.SetProgressorLabel("Performing Interpolations for: "+Precip_Map.shp+" and determining best Interpolation")
        #
        #Perform all interpolations, and statistically compare them
        #to dermine the best method

        Precip_Map.Perform_Interpolation(cell_size,output_dir)
        arcpy.SetProgressorPosition()
        arcpy.AddMessage("Finalizing Results for "+Precip_Map.shp+", and adding them to Map Doc.")
        #
        #Add the best method to the current map doc,
        #along with the shapefile containing the spatial extent
        Precip_Map.finalize(Output_counter,clip_extent)
        arcpy.SetProgressorPosition()
    
    arcpy.AddMessage("All done!") 
    arcpy.AddMessage("Results, and details on each file can be seen in the log.txt files in each Interpolation Results folders")
    arcpy.ResetProgressor()
        
        