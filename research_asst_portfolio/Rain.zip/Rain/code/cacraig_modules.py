import arcpy,sys,os,glob
from arcpy.sa import *

class Precip_Map:
    def __init__(self,filename,filecount):
        """
        Initialization for Precip_Map object
        """
        self.filename=filename #stores CSV filename
        self.shp="" #Stores name of shapefile for precip points
        self.lyr="" #Stores layer name for Precip point output
        self.IDW_Output="" #stores name for Inverse Distance Wieghted Interpolation output
        self.RB_Output="" #stores name for Radial Basis Interpolation output
        self.Local_Output="" #stores name for Local Polynomial Interpolation output
        self.Best="" #stores layer name w/ best RMSE
        self.Z_field="" #stores name of data type
        self.Output_Counter=filecount

    
    def Get_Data_From_ASCII(self,output_dir,filename):
        """
        Converts comma-seperated files into dbf and shapefiles. All data is saved to given output directory. 
        @param1 - Output Directory to save to.
        """
        data=arcpy.TableToTable_conversion(self.filename,output_dir,self.filename.split(".")[0]+".dbf")
        output=(filename.split(".")[0])[:4]+str(self.Output_Counter)
        spRef = r"Coordinate Systems\Geographic Coordinate Systems\World/WGS 1984.prj"
        lyr=arcpy.MakeXYEventLayer_management(data, "Lon", "Lat", output,spRef)
        shp=arcpy.MakeFeatureLayer_management(lyr,output+".shp")
        temp=arcpy.env.workspace
        arcpy.env.workspace=output_dir
        arcpy.CopyFeatures_management(shp,output+".shp")
        arcpy.env.workspace=temp
        self.shp=output+".shp"
        self.lyr=output+".lyr"

    def Perform_Interpolation(self,cell_size,output_dir):
        """
        Performs various interpolations (Local Polynomial, IDW, and Radial Basis), then determines best method. Stats, and file information is written to log.txt
        @param1- Cell size. 
        @param2- Output directory to save files to. 
        """

        if cell_size=="SAME AS MPE":
           cell_size=.049
        elif cell_size=="DEFAULT":
            cell_size=""

        output_file=self.shp.split(".")[0]+"_R"
        #output_file=output_file.split("_")[1]+"_RB"
        out_g_lyr=output_file.split("_")[0]+"_g"
            
        output_file2=self.shp.split(".")[0]+"_I"
        #output_file2=output_file2.split("_")[1]+"_IDW"
        out_g_lyr2=output_file2.split("_")[0]+"_g"

        output_file3=self.shp.split(".")[0]+"_L"
        #output_file3=output_file3.split("_")[1]+"_L"
        out_g_lyr3=output_file3.split("_")[0]+"_g"
            


        #Open log file.
        f = open(output_dir+"\log.txt", 'w')
        f.write("#########################################################################\n\n")

        #Perform Cross validations
        #Compare RMSE of each Interpolation model.
        
        arcpy.CheckOutExtension("Spatial")
        arcpy.CheckOutExtension("GeoStats")

        arcpy.RadialBasisFunctions_ga(self.shp,self.Z_field,out_g_lyr,output_dir+"/"+output_file,cell_size,"","SPLINE_WITH_TENSION","")
        cvresult_RB=arcpy.CrossValidation_ga(out_g_lyr)
        RMSE_RB=cvresult_RB.rootMeanSquare
        self.RB_Output=output_file
        f.write("Radial Basis results for "+self.shp+" are stored in "+output_file+"\n")

        cell_size=""

        arcpy.LocalPolynomialInterpolation_ga(self.shp,self.Z_field,out_g_lyr3,output_dir+"/"+output_file3,cell_size,"","","","","","","","")
        cvresult_Local=arcpy.CrossValidation_ga(out_g_lyr3)
        RMSE_Local=cvresult_Local.rootMeanSquare
        self.Local_Output=output_file3
        f.write("Local Polynomial results for "+self.shp+" are stored in "+output_file3+"\n\n")

        cell_size=""

        
        arcpy.IDW_ga(self.shp,self.Z_field,out_g_lyr2,output_dir+"/"+output_file2,cell_size,"","")
        cvresult_IDW=arcpy.CrossValidation_ga(out_g_lyr2)
        RMSE_IDW=cvresult_IDW.rootMeanSquare
        self.IDW_Output=output_file2
        f.write("Inverse Distance Wieghted results for "+self.shp+" are stored in "+output_file2+"\n")

        
        


        f.write("Root Mean Square error for Inverse Distance Weighted Interpolation= "+str(RMSE_IDW)+"\n")
        f.write("Root Mean Square error for Local Polynomial Interpolation= "+str(RMSE_Local)+"\n")
        f.write("Root Mean Square error for Radial Basis Interpolation = "+str(RMSE_RB)+"\n\n")

        #Find the Interpolation method with the lowest RMSE. 
        search_dict={"IDW":RMSE_IDW,"Local":RMSE_Local,"RB":RMSE_RB}
        lowest=min(search_dict, key=search_dict.get)

        f.write("The Interpolation with the lowest RMSE is "+lowest+"\nwith a value of: "+search_dict[lowest]+"\n")
        f.write("#########################################################################\n\n")
        f.close()

        #Set self.Best to the best method determined for later use.
        if lowest == "IDW":
            self.Best=output_file2
        elif lowest == "Local":
            self.Best=output_file3
        elif lowest == "RB":
            self.Best=output_file

        return 0

    def finalize(self,Output_counter,clip_extent=""):
        """
        Takes the determined best interpolation, clips it to a specified spatial extent, and adds it to the current map doc.
        @param1- Output counter. Keeps track and coordinate resultant raster of the input precipitation data.
        @param2- spatial extent of resultant rasters. A feature class. (optional). If none specified, resultant raster will not be masked to any extent
        """
        nospat=1
        mxd = arcpy.mapping.MapDocument("CURRENT")
        dfs = arcpy.mapping.ListDataFrames(mxd)
        df = dfs[0]
        if Output_counter==1 and clip_extent !="":
            addLayer = arcpy.mapping.Layer(clip_extent)
            arcpy.mapping.AddLayer(df,addLayer)

        if clip_extent == "":
            path=os.path.split(arcpy.env.workspace)[0]
            dir=os.listdir(path)
            for file in dir:
                #Search for NC.shp if no spatial extent specified.
                if file== "NC.shp":
                    if Output_counter==1:
                        addLayer=arcpy.mapping.Layer(path+"/"+file)
                        arcpy.mapping.AddLayer(df,addLayer)
                    outExtractByMask = ExtractByMask(self.Best,file)
                    outExtractByMask.save(arcpy.env.workspace+"/"+self.shp.split(".")[0]+"_"+self.Best.split("_")[1])
                    addLayer = arcpy.mapping.Layer(arcpy.env.workspace+"/"+self.shp.split(".")[0]+"_"+self.Best.split("_")[1])
                    arcpy.mapping.AddLayer(df,addLayer)
                    nospat=0 #NC.shp found, No Spaital extent = false
            #If NC.shp does not exist, use no spatial extent
            if nospat==1:
                addLayer = arcpy.mapping.Layer(path+"/"+self.Best)
                arcpy.mapping.AddLayer(df,addLayer)
        #Use specified feature class for spatial extent.
        else:
            outExtractByMask = ExtractByMask(self.Best,clip_extent)
            outExtractByMask.save(arcpy.env.workspace+"/"+self.shp.split(".")[0]+"_"+self.Best.split("_")[1])
            addLayer = arcpy.mapping.Layer(arcpy.env.workspace+"/"+self.shp.split(".")[0]+"_"+self.Best.split("_")[1])
            arcpy.mapping.AddLayer(df,addLayer)


        del mxd
        
        return 0