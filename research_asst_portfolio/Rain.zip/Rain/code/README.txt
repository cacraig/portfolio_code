*\cacraig\data contains 3 sample data files as follows:

Gauge.csv //Contains Gauge data from all networks in NC
Impact.csv //Contains Gauge data from all networks in NC, with ECONet Impact Sensor data included in place of Gauge
Others.csv //Contains only networks' gauge data, excluding ECONet's Gauge/Impact Sensor data. 

The period is 10/16/2011 to 10/18/2011.

*\cacraig\code contains the main script, modules, toolbox, and map document with toolbar (Tap the kitty to execute the tool). 

*\cacraig\documentation contains documentation.




***************NOTE****************

I have had extreme difficulty with getting this script to run consistantly through wishbone. When it does run, it is extremely slow. The errors are almost always different. 
I think the issue might have something to do with this slow shuttling of data back forth,  complicated further by the constant reading/writing that my script requires. 

The script will work on any other machine just fine however. 

So in summation this script works locally, but works through VPN (sometimes).

*********************************** 