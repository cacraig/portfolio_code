/*
*rider.c
*file containing the thread function.
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "ride.h"

/*
*void *rider(void *args)
*Executes Rider thread
*
*@param void *args - pointer to the Passenger ID pertaining to this thread.
*/

void *rider(void *args) {
int Passenger_ID = *((int *)args);
int carID;

while(1){
	printf("Rider %d is now walking in park \n",Passenger_ID);
	walkAroundTime(); //wait for some time.
   	carID=getInLine(); //carID = car taken/being riden.
	printf("Rider %d is now riding in car %d \n",Passenger_ID,carID);
   	rideTime();//ride around for some time
   	returnCar(carID);//return the car
	printf("Rider %d returned car %d \n",Passenger_ID,carID);
	}

pthread_exit(0);
}
