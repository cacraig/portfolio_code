/*
*sleeper.c
*contains functions for Ride Time (ammount of time rider is riding in car),
*and Time the rider is walking around.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>
#include "ride.h"

void rideTime();
void walkAroundTime();


void rideTime() {

int seconds = ( random() % 5) + 1 ;
sleep (seconds); 
}

void walkAroundTime() {

int seconds = (random() % 10) + 1 ;
sleep (seconds);
}
