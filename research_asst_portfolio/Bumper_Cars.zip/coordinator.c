/*
*coordinator.c
*
*Manages the bounded buffer.
*
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>
#include <assert.h>
#include "ride.h"

/*Coordinator*/ 


/*getInLine() 
*
*consumerGet function
*Rider gets in line, waits for car, if car is available, rider rides car, else waits.
*@return int c - Id of car taken.
*/
int getInLine(){
	pthread_mutex_lock( &m1 );

	while(cnt==0){
	pthread_cond_wait(&full,&m1);}//if no car available, block
      
	//car available, get in car.
	int c = carID[out]; //c=car being riden
  	out = (out + 1) % num_of_cars; 
  	cnt--;//remove car from buffer

	pthread_mutex_unlock( &m1 );
  	pthread_cond_signal(&empty); 

	//return carID
     	 return c;}

/*
*returnCar(int carId)
*Returns the car to the buffer, and increments the buffer count.
*@param int carId - Car being returned
*/

returnCar (int carId){
	pthread_mutex_lock( &m1 );  //Obtain the mutex

	/*place carId in buffer*/
	carID[in]=carId;
	in = (in + 1) % num_of_cars;
  	cnt++;
	/*unblock a  waiting thread*/
	pthread_mutex_unlock( &m1 );      //Unlock the mutex
  	pthread_cond_signal( &full );    //Signal consumers
      
      
}
