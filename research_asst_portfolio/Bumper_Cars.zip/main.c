#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <assert.h>
#include <time.h>
#include "ride.h"

/*
*Colin Craig
*11/15/11
*Homework #6
*
*To compile: gcc -o ride main.c rider.c sleeper.c coordinator.c -lpthread
*To execute ./ride.out <initial entries(cars)> <rider threads> <simulation time>
*
*/
int *carID;
int in=0;
int out=0;
int cnt=0;
pthread_mutex_t m1= PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty= PTHREAD_COND_INITIALIZER;
pthread_cond_t full= PTHREAD_COND_INITIALIZER ;

/*
*main.c
*This file contains the main() for the program. It initializes the rider threads, car buffer, and sleeps
*for a specified unit of time. 
*/
int
main(int argc, char *argv[]) {
	int rc,i,sleep_time;

	pthread_t *my_threads;

	num_of_cars = atoi(argv[1]); //retrieve number of cars available to ride
	num_of_threads= atoi(argv[2]); //number of passengers
	sleep_time=atoi(argv[3]); //Time to run simulation

	cnt=num_of_cars; //set cnt = number of cars available
	int passenger[num_of_threads];//set up passenger array, with number of passengers/riders.
	


	carID=(int*) malloc(num_of_cars*sizeof(int));//allocate car array
	my_threads=(pthread_t*) malloc(num_of_threads*sizeof(pthread_t)); //Allocate thread array

	for(i=0;i<num_of_cars;i++){ //Initialize/Assign car values
		carID[i]=i+1;}

	for(i=0;i<num_of_threads;i++){ //Initialize/Assign rider values
		passenger[i]=i+1;}
		
	
for (i = 0; i < num_of_threads ; i++){
	rc= pthread_create(&my_threads[i],PTHREAD_CREATE_JOINABLE,rider, (void*) &passenger[i]); //Create Rider Thread
	assert(rc==0);}

	sleep(sleep_time);//sleep for sleep_time seconds
	exit(0);//exit 

}





