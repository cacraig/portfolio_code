
Colin Craig
11/15/11
Homework #6

To compile: gcc -o ride main.c rider.c sleeper.c coordinator.c -lpthread
To execute ./ride <initial entries(cars)> <rider threads> <simulation time>

compiled on Unix machine.
