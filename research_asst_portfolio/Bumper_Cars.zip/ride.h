/*
*ride.h
*header file that contains all the global variables/functions
*
*/
extern pthread_mutex_t m1;
extern pthread_cond_t empty;
extern pthread_cond_t full ;
extern int cnt;
extern int in;
extern int out;
extern int *carID;



#ifndef DATA_H
#define DATA_H
int num_of_cars,num_of_threads;
#endif

#ifndef RIDER_H
#define RIDER_H
extern void * rider(void *args);
#endif

#ifndef SLEEP_H
#define SLEEP_H
extern void rideTime();
extern void walkAroundTime();
#endif

#ifndef COOR_H
#define COOR_H
extern returnCar (int carId);
extern int getInLine();
#endif
